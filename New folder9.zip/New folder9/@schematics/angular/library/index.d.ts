import { Rule } from '@angular-devkit/schematics';
import { Schema as LibraryOptions } from './schema';
export default function (options: LibraryOptions): Rule;
