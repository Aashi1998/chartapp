import { ModuleWithProviders } from '@angular/core';
export declare class PlotlyModule {
    constructor();
    static forRoot(): ModuleWithProviders;
}
