module.exports = require('regenerate')(0x85E).addRange(0x840, 0x85B);
