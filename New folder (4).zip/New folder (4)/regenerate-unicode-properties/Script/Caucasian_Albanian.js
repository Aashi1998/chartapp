module.exports = require('regenerate')(0x1056F).addRange(0x10530, 0x10563);
