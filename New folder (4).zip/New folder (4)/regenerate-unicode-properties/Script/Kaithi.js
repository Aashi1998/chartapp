module.exports = require('regenerate')(0x110CD).addRange(0x11080, 0x110C1);
