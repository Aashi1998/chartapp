module.exports = require('regenerate')(0x1145B).addRange(0x11400, 0x11459).addRange(0x1145D, 0x1145E);
