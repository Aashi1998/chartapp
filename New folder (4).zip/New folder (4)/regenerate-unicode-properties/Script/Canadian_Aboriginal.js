module.exports = require('regenerate')().addRange(0x1400, 0x167F).addRange(0x18B0, 0x18F5);
