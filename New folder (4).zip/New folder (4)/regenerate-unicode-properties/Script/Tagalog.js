module.exports = require('regenerate')().addRange(0x1700, 0x170C).addRange(0x170E, 0x1714);
