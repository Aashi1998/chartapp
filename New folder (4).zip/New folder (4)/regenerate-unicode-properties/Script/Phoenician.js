module.exports = require('regenerate')(0x1091F).addRange(0x10900, 0x1091B);
