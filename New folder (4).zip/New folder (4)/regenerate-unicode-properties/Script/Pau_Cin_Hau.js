module.exports = require('regenerate')().addRange(0x11AC0, 0x11AF8);
