module.exports = require('regenerate')().addRange(0x0, 0x10FFFF);
