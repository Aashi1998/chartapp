## 0.1.0

* Adds [rotateAround](https://github.com/mapbox/point-geometry/pull/5) and
  [multByPoint](https://github.com/mapbox/point-geometry/pull/7) and divByPoint
  methods.
