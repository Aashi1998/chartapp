module.exports = require('regenerate')(0xA92F).addRange(0xA900, 0xA92D);
