module.exports = require('regenerate')().addRange(0x10A80, 0x10A9F);
