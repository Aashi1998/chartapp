module.exports = require('regenerate')().addRange(0x102A0, 0x102D0);
