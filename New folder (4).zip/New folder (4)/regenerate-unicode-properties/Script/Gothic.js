module.exports = require('regenerate')().addRange(0x10330, 0x1034A);
