module.exports = require('regenerate')().addRange(0x11680, 0x116B7).addRange(0x116C0, 0x116C9);
