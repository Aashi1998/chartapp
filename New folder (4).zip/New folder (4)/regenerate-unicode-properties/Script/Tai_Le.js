module.exports = require('regenerate')().addRange(0x1950, 0x196D).addRange(0x1970, 0x1974);
