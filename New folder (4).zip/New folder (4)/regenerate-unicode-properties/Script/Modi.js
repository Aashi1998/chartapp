module.exports = require('regenerate')().addRange(0x11600, 0x11644).addRange(0x11650, 0x11659);
