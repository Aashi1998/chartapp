export declare class Angular2CsvService {
    constructor();
}
