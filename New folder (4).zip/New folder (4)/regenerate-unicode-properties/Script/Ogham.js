module.exports = require('regenerate')().addRange(0x1680, 0x169C);
