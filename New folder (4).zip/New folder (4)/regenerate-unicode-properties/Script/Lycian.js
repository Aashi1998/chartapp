module.exports = require('regenerate')().addRange(0x10280, 0x1029C);
