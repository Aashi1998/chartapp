# No warning for complex filename templates
