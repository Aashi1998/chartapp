module.exports = require('regenerate')().addRange(0x10D00, 0x10D27).addRange(0x10D30, 0x10D39);
