module.exports = require('regenerate')().addRange(0x16F00, 0x16F44).addRange(0x16F50, 0x16F7E).addRange(0x16F8F, 0x16F9F);
