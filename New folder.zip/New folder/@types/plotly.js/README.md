# Installation
> `npm install --save @types/plotly.js`

# Summary
This package contains type definitions for plotly.js ( https://plot.ly/javascript/ ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/plotly.js

Additional Details
 * Last updated: Wed, 13 Feb 2019 21:04:43 GMT
 * Dependencies: @types/d3
 * Global values: Plotly

# Credits
These definitions were written by Chris Gervang <https://github.com/chrisgervang>, Martin Duparc <https://github.com/martinduparc>, Frederik Aalund <https://github.com/frederikaalund>, taoqf <https://github.com/taoqf>, Dadstart <https://github.com/Dadstart>, Jared Szechy <https://github.com/szechyjs>, Drew Diamantoukos <https://github.com/MercifulCode>, Sooraj Pudiyadath <https://github.com/soorajpudiyadath>, Jon Freedman <https://github.com/jonfreedman>, Megan Riel-Mehan <https://github.com/meganrm>.
