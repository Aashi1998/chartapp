module.exports = require('regenerate')().addRange(0x1740, 0x1753);
