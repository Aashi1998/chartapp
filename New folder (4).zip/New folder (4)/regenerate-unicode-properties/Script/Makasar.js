module.exports = require('regenerate')().addRange(0x11EE0, 0x11EF8);
