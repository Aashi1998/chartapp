export * from './core/index';
import * as lin_ from './lin/index';
import * as stats_ from './stats/index';

export const lin = lin_;
export const stats = stats_;