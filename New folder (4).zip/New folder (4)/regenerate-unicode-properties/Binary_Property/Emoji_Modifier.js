module.exports = require('regenerate')().addRange(0x1F3FB, 0x1F3FF);
