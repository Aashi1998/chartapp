# webpack-core

The shared core of [webpack](https://github.com/webpack/webpack) and [enhanced-require](https://github.com/webpack/enhanced-require).

It mainly encapsulate

* the loader stuff
* SourceMap stuff

Not useable as standalone module, but this may change in the future.

# License

Copyright (c) 2012 - 2013 Tobias Koppers

MIT (http://www.opensource.org/licenses/mit-license.php)