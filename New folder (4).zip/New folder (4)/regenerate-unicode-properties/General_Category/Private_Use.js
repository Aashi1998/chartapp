module.exports = require('regenerate')().addRange(0xE000, 0xF8FF).addRange(0xF0000, 0xFFFFD).addRange(0x100000, 0x10FFFD);
