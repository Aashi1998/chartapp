import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { MyLineChartComponent } from './my-line-chart/my-line-chart.component';
import { MyRadarChartComponent } from './my-radar-chart/my-radar-chart.component';
import { MyPieChartComponent } from './my-pie-chart/my-pie-chart.component';
import { MyBubbleChartComponent } from './my-bubble-chart/my-bubble-chart.component';
import { PlotlyExampleComponent } from './plotly-example/plotly-example.component';
import { MyBoxplotChartComponent } from './my-boxplot-chart/my-boxplot-chart.component';
import { MyTryChartComponent } from './my-try-chart/my-try-chart.component';

const routes: Routes = [
{path:'bar-chart' , component:MyBarChartComponent},
{path:'line-chart' , component:MyLineChartComponent},
{path:'radar-chart' , component:MyRadarChartComponent},
{path:'pie-chart' , component:MyPieChartComponent},
{path:'bubble-chart' , component:MyBubbleChartComponent},
{path:'plotly-example' , component:PlotlyExampleComponent},
 {path:'boxplot-example' , component:   MyBoxplotChartComponent},
 {path:'try-example' , component:MyTryChartComponent},
{path:'**' , component:MyBarChartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
