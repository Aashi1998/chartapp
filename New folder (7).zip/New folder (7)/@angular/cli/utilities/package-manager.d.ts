export declare function supportsYarn(): boolean;
export declare function supportsNpm(): boolean;
export declare function getPackageManager(root: string): string;
