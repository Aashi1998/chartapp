module.exports = require('regenerate')().addRange(0x1735, 0x1736).addRange(0x1740, 0x1753);
