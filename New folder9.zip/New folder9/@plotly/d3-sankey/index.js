export {default as sankey} from "./src/sankey";
