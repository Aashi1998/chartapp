module.exports = require('regenerate')(0x118FF).addRange(0x118A0, 0x118F2);
