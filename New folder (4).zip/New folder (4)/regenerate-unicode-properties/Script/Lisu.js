module.exports = require('regenerate')().addRange(0xA4D0, 0xA4FF);
