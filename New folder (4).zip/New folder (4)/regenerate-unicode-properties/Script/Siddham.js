module.exports = require('regenerate')().addRange(0x11580, 0x115B5).addRange(0x115B8, 0x115DD);
