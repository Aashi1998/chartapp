module.exports = require('regenerate')().addRange(0x10400, 0x1044F);
