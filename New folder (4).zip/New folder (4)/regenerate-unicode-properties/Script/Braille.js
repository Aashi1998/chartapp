module.exports = require('regenerate')().addRange(0x2800, 0x28FF);
