module.exports = require('regenerate')().addRange(0x104B0, 0x104D3).addRange(0x104D8, 0x104FB);
