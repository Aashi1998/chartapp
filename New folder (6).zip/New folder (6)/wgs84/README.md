# [wgs84](http://en.wikipedia.org/wiki/World_Geodetic_System)

Provides `RADIUS`, `FLATTENING`, and `POLAR_RADIUS` constants from
the reference ellipsoid.
