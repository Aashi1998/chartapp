/**
 * Euler's constant.
 */
export const EULER = .5772156649015329;
