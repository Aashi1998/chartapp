module.exports = require('regenerate')().addRange(0x11800, 0x1183B);
