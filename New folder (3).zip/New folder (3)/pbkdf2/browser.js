exports.pbkdf2 = require('./lib/async')
exports.pbkdf2Sync = require('./lib/sync')
