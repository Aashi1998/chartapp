import { Component, OnInit , ViewChild, ElementRef} from '@angular/core';
import * as Plotly from 'plotly.js';
@Component({
  selector: 'app-my-boxplot-chart',
  templateUrl: './my-boxplot-chart.component.html',
  styleUrls: ['./my-boxplot-chart.component.css']
})
export class MyBoxplotChartComponent implements OnInit {

  @ViewChild('chart') el: ElementRef;
   public csvRecords: any[]= [];
  @ViewChild('fileImportInput') fileImportInput: any;
 fileChangeListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    if (this.isCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
         var zz=this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        var m=zz[2];
     var n=zz[1];
     var d=[];

for(let i=0;i<n.length;i++)
{
d.push(parseFloat(n[i]));

}
      this.basicChart(n);
            
      };

      reader.onerror = function () {
        alert('Unable to read ' + input.files[0]);
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let dataArr = [];
  var a=[];
 var b=[];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let data = (<string>csvRecordsArray[i]).split(',');

      // FOR EACH ROW IN CSV FILE IF THE NUMBER OF COLUMNS
      // ARE SAME AS NUMBER OF HEADER COLUMNS THEN PARSE THE DATA
      if (data.length == headerLength) {

        let csvRecord: CSVRecord = new CSVRecord();

        csvRecord.firstName = data[0].trim();
        csvRecord.lastName = data[1].trim();
        csvRecord.email = data[2].trim();
      

        dataArr.push(csvRecord);
        a.push(csvRecord.lastName);
        b.push(csvRecord.firstName);
      }
    }
      
    console.log(a);
    return [dataArr, a, b];
  }

  isCSVFile(file: any) {
    return 1;
  }

  
  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = [];
  }

  basicChart(l) {
    const element = this.el.nativeElement

    const data = [{
    x: l,
    type: 'box'
    }]

    Plotly.plot( element, data );
  }
  
  constructor() { }

  ngOnInit() {
  
  }
}
export class CSVRecord {

  public firstName: any;
  public lastName: any;
  public email: any;


  constructor() {

  }
  
}

