A library is a type of project that does not run independently.
The library skeleton created by this command is placed by default in the `/projects` folder, and has `type` of "library".

You can build a new library using the `ng build` command, run unit tests for it using the `ng test` command,
and lint it using the `ng lint` command.