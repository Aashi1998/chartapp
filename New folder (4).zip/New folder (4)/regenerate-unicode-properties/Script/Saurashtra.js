module.exports = require('regenerate')().addRange(0xA880, 0xA8C5).addRange(0xA8CE, 0xA8D9);
