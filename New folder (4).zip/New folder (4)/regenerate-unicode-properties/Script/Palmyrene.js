module.exports = require('regenerate')().addRange(0x10860, 0x1087F);
