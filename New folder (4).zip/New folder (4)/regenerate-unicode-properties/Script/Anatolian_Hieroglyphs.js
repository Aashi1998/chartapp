module.exports = require('regenerate')().addRange(0x14400, 0x14646);
