
 import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import {Chart} from 'chart.js';

@Component({
  selector: 'app-my-try-chart',
  templateUrl: './my-try-chart.component.html',
  styleUrls: ['./my-try-chart.component.css']
})
export class MyTryChartComponent implements OnInit {

  title = 'app';
  LineChart=[];
  public csvRecords:any[]=[];

  @ViewChild('fileImportInput') fileImportInput: any;

  fileChangeListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    if (this.isCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);
        var ques=" ";
        for (var i=1;i<headersRow.length;i++)
        {
        ques=ques+"Enter "+(i)+" for: "+(headersRow[i])+" ";
        
        }
       console.log(ques);
        var person = prompt(ques, "1");
        var k=headersRow[person];
        this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length,person);
        var zz=this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length,person);
        var n=zz[1];
        var x = [], y = [], prev;
        var arr=n;
     if(isNaN(n[2]))
     {
        arr.sort();
        for ( var i = 0; i < arr.length; i++ ) {
        if ( arr[i] !== prev ) {
            x.push(arr[i]);
            y.push(1);
        } else {
            y[y.length-1]++;
        }
        prev = arr[i];
    } 
    console.log(x);
    console.log(y);
     }
     else{
       for ( var i = 0; i < n.length; i++ ){
        y.push(n[i]);
        x.push((i+1));
}
     console.log(x);
    console.log(y);  
     }
     this.LineChart = new Chart('linechart', {
                type: 'bar',
                data: {
                    labels: x,
                    datasets: [{
                        label: k,
                        data: y,
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.2)'
                           
                        ],
                        borderColor: [
                          
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                 stepSize: 4
                            }
                        }]
                    }
                }
            });
            
      };

      reader.onerror = function () {
        alert('Unable to read ' + input.files[0]);
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any, per) {
 let dataArr = [];
 var a=[];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let data = (<string>csvRecordsArray[i]).split(',');

      // FOR EACH ROW IN CSV FILE IF THE NUMBER OF COLUMNS
      // ARE SAME AS NUMBER OF HEADER COLUMNS THEN PARSE THE DATA
      if (data.length == headerLength) {

        let csvRecord: CSVRecord = new CSVRecord();

        csvRecord.firstName = data[per].trim();
        dataArr.push(csvRecord);
        a.push(csvRecord.firstName);
      }
    }
      
    console.log(a);
    return [dataArr, a];
  }

  // CHECK IF FILE IS A VALID CSV FILE
  isCSVFile(file: any) {
    return 1;
  }

  // GET CSV FILE HEADER COLUMNS
  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = [];
  }

   constructor() { }

  ngOnInit() {  
  }

}

export class CSVRecord {

  public firstName: any;



  constructor() {

  }
  
}
