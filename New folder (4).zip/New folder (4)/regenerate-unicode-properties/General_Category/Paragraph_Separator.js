module.exports = require('regenerate')(0x2029);
