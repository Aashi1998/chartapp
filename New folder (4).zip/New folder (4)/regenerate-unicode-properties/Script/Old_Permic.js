module.exports = require('regenerate')().addRange(0x10350, 0x1037A);
