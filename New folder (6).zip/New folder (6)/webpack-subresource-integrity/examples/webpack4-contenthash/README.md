# Ensure contenthash path variable works in Webpack 4.3+

Test case for issue #78
