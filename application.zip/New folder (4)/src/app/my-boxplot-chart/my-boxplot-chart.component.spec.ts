import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBoxplotChartComponent } from './my-boxplot-chart.component';

describe('MyBoxplotChartComponent', () => {
  let component: MyBoxplotChartComponent;
  let fixture: ComponentFixture<MyBoxplotChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBoxplotChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBoxplotChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
