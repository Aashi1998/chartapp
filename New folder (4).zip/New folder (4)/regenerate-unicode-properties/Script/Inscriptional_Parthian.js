module.exports = require('regenerate')().addRange(0x10B40, 0x10B55).addRange(0x10B58, 0x10B5F);
