module.exports = require('regenerate')().addRange(0x2FF2, 0x2FF3);
