module.exports = require('regenerate')().addRange(0xA000, 0xA48C).addRange(0xA490, 0xA4C6);
