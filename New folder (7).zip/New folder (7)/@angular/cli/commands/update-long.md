Perform a basic update to v7 of the core framework and CLI by running the following command.

```
ng update @angular/cli @angular/core
```

For detailed information and guidance on updating your application, see the interactive [Angular Update Guide](https://update.angular.io/).
