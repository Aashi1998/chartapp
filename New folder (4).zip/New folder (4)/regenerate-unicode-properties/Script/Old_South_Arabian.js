module.exports = require('regenerate')().addRange(0x10A60, 0x10A7F);
