module.exports = require('regenerate')(0x16FE0).addRange(0x17000, 0x187F1).addRange(0x18800, 0x18AF2);
