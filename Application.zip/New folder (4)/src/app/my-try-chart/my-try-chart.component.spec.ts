import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyTryChartComponent } from './my-try-chart.component';

describe('MyTryChartComponent', () => {
  let component: MyTryChartComponent;
  let fixture: ComponentFixture<MyTryChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyTryChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyTryChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
