require('./weakmap.js')
require('./create-store.js')