# Installation
> `npm install --save @types/chart.js`

# Summary
This package contains type definitions for Chart.js ( https://github.com/nnnick/Chart.js ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/chart.js

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:48 GMT
 * Dependencies: none
 * Global values: Chart

# Credits
These definitions were written by Alberto Nuti <https://github.com/anuti>, Fabien Lavocat <https://github.com/FabienLavocat>, KentarouTakeda <https://github.com/KentarouTakeda>, Larry Bahr <https://github.com/larrybahr>, Daniel Luz <https://github.com/mernen>, Joseph Page <https://github.com/josefpaij>, Dan Manastireanu <https://github.com/danmana>, Guillaume Rodriguez <https://github.com/guillaume-ro-fr>, Simon Archer <https://github.com/archy-bold>, Ken Elkabany <https://github.com/braincore>, Francesco Benedetto <https://github.com/frabnt>, Alexandros Dorodoulis <https://github.com/alexdor>, Manuel Heidrich <https://github.com/mahnuh>, Conrad Holtzhausen <https://github.com/Conrad777>.
