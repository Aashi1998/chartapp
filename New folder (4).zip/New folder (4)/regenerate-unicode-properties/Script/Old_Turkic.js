module.exports = require('regenerate')().addRange(0x10C00, 0x10C48);
