module.exports = require('regenerate')().addRange(0x10450, 0x1047F);
