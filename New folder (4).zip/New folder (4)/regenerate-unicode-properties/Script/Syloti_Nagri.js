module.exports = require('regenerate')().addRange(0xA800, 0xA82B);
