'use strict'

var tape = require('tape')
var aff  = require('../aff')

tape('affine-hull', function(t) {

  t.end()
})