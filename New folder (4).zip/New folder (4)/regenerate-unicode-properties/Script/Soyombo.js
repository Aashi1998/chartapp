module.exports = require('regenerate')().addRange(0x11A50, 0x11A83).addRange(0x11A86, 0x11AA2);
