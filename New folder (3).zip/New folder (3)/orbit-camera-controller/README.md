orbit-camera-controller
=======================
A controller for freely moving orbit cameras.  Supports the same interactions as 3D-view.

[![build status](https://secure.travis-ci.org/mikolalysenko/orbit-camera-controller.png)](http://travis-ci.org/mikolalysenko/orbit-camera-controller)

# Install

```
npm i orbit-camera-controller
```

# License
(c) 2015 Mikola Lysenko. MIT License