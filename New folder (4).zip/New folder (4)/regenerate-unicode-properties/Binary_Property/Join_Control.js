module.exports = require('regenerate')().addRange(0x200C, 0x200D);
