export default function ascending(a, b) {
  return a - b;
};
