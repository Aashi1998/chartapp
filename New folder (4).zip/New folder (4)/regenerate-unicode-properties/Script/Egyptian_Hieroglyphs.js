module.exports = require('regenerate')().addRange(0x13000, 0x1342E);
