module.exports = require('regenerate')().addRange(0x10F00, 0x10F27);
