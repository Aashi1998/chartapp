/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { SharedModule as ɵa } from './src/app/shared/shared.module';
