module.exports = require('regenerate')().addRange(0x11A00, 0x11A47);
