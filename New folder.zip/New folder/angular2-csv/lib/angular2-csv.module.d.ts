export declare class Angular2CsvModule {
}
