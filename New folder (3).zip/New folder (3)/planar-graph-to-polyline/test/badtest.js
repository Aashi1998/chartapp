var tape = require('tape')
var graphToPolyline = require("../pg2pl.js")
var badcurve = require('./badcurve.json')


tape('bad curve', function(t) {

  graphToPolyline(badcurve.edges, badcurve.positions)

  t.end()
})