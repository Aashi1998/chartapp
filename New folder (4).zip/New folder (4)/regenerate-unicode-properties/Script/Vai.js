module.exports = require('regenerate')().addRange(0xA500, 0xA62B);
