module.exports = require('regenerate')().addRange(0x1C50, 0x1C7F);
