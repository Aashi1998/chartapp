module.exports = require('regenerate')(0xA95F).addRange(0xA930, 0xA953);
