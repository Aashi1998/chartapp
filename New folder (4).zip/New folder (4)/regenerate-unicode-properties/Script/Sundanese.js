module.exports = require('regenerate')().addRange(0x1B80, 0x1BBF).addRange(0x1CC0, 0x1CC7);
