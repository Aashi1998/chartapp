module.exports = require('regenerate')().addRange(0x1F1E6, 0x1F1FF);
