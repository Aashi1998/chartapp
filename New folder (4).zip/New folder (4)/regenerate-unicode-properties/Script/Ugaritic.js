module.exports = require('regenerate')(0x1039F).addRange(0x10380, 0x1039D);
