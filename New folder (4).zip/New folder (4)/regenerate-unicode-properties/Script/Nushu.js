module.exports = require('regenerate')(0x16FE1).addRange(0x1B170, 0x1B2FB);
