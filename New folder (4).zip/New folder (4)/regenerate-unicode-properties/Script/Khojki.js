module.exports = require('regenerate')().addRange(0x11200, 0x11211).addRange(0x11213, 0x1123E);
