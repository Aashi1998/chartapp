# Warning when Used with Hot Reloading

Test case for issue #46
