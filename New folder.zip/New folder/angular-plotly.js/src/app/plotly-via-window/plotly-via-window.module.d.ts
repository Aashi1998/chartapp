import { ModuleWithProviders } from '@angular/core';
export declare class PlotlyViaWindowModule {
    constructor();
    static forRoot(): ModuleWithProviders;
}
