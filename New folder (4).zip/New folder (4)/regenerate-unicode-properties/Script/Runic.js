module.exports = require('regenerate')().addRange(0x16A0, 0x16EA).addRange(0x16EE, 0x16F8);
