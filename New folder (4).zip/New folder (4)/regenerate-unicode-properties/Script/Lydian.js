module.exports = require('regenerate')(0x1093F).addRange(0x10920, 0x10939);
