module.exports = require('regenerate')().addRange(0x10980, 0x1099F);
