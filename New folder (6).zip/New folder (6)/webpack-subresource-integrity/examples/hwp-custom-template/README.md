# HtmlWebpackPlugin and Custom Template #hwp

Test case for issue #13
