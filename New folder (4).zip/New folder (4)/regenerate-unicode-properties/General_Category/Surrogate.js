module.exports = require('regenerate')().addRange(0xD800, 0xDFFF);
