module.exports = require('regenerate')().addRange(0x10500, 0x10527);
