module.exports = require('regenerate')().addRange(0xA840, 0xA877);
