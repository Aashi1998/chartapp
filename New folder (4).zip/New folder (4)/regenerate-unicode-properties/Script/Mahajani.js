module.exports = require('regenerate')().addRange(0x11150, 0x11176);
