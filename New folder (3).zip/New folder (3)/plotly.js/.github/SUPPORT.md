Implementation help may be found on community.plot.ly (tagged
[`plotly-js`](http://community.plot.ly/c/plotly-js)) or on Stack Overflow
(tagged [`plotly`](https://stackoverflow.com/questions/tagged/plotly)).

Direct developer email support can be purchased through a [Plotly Support
Plan](https://support.plot.ly/libraries/javascript).
