exports['world_110m'] = require('./dist/world_110m.json');
exports['world_50m'] = require('./dist/world_50m.json');

exports['africa_110m'] = require('./dist/africa_110m.json');
exports['africa_50m'] = require('./dist/africa_50m.json');

exports['asia_110m'] = require('./dist/asia_110m.json');
exports['asia_50m'] = require('./dist/asia_50m.json');

exports['europe_110m'] = require('./dist/europe_110m.json');
exports['europe_50m'] = require('./dist/europe_50m.json');

exports['north-america_110m'] = require('./dist/north-america_110m.json');
exports['north-america_50m'] = require('./dist/north-america_50m.json');

exports['south-america_110m'] = require('./dist/south-america_110m.json');
exports['south-america_50m'] = require('./dist/south-america_50m.json');

exports['usa_110m'] = require('./dist/usa_110m.json');
exports['usa_50m'] = require('./dist/usa_50m.json');
