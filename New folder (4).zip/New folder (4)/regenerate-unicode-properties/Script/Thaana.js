module.exports = require('regenerate')().addRange(0x780, 0x7B1);
